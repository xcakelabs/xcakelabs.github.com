//
//  XCDetailViewController.h
//  XCakeLab1
//
//  Created by Damien Glancy on 10/09/2012.
//  Copyright (c) 2012 XCake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XCDetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;

@property (weak, nonatomic) IBOutlet UILabel *detailDescriptionLabel;
@end
