//
//  main.m
//  XCakeLab1
//
//  Created by Damien Glancy on 10/09/2012.
//  Copyright (c) 2012 XCake. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "XCAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([XCAppDelegate class]));
    }
}
