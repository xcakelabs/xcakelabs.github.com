//
//  XCMasterViewController.h
//  XCakeLab1
//
//  Created by Damien Glancy on 10/09/2012.
//  Copyright (c) 2012 XCake. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <CoreData/CoreData.h>

@interface XCMasterViewController : UITableViewController <NSFetchedResultsControllerDelegate>

@property (strong, nonatomic) NSFetchedResultsController *fetchedResultsController;
@property (strong, nonatomic) NSManagedObjectContext *managedObjectContext;

@end
