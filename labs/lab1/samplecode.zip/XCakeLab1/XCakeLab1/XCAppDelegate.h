//
//  XCAppDelegate.h
//  XCakeLab1
//
//  Created by Damien Glancy on 10/09/2012.
//  Copyright (c) 2012 XCake. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XCAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
