//
//  Event.h
//  XCakeLab1
//
//  Created by Damien Glancy on 10/09/2012.
//  Copyright (c) 2012 XCake. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Event : NSManagedObject

@property (nonatomic, retain) NSDate * timeStamp;
@property (nonatomic, retain) NSString * location;

@end
